# this assignment is done with the help of opencv
import cv2
import numpy as np

# Ive used these images according to the features i will need to see the effect of the filter clearly

img_normal = cv2.imread("test_images/blob.png")
#Clean shapes, great for basic demo

img_blur = cv2.imread("test_images/bluegill.png")
#Natural textures — blur softens it

img_sharp = cv2.imread("test_images/construct.png")
#Has structure/edges that sharpen well

img_edge = cv2.imread("test_images/chess.png")
#Strong geometric lines — shows edges clearly

img_pad = cv2.imread("test_images/centered_pixel.png")
#Central focus; padding effect is visual

img_lpf = cv2.imread("test_images/mushroom.png")
#Smooth curves, blur softens details

img_hpf = cv2.imread("test_images/tree.png")
#High-frequency edges in branches — subtractive HPF enhances them

img_freq = cv2.imread("test_images/pattern.png")
#Has repeated structure — shows frequency behavior well

# normal image
cv2.imshow("Original", img_normal)

# Grayscaled image
grayed_normal = cv2.cvtColor(img_normal, cv2.COLOR_BGR2GRAY)
cv2.imshow("Grayscale", grayed_normal)

# applying Gaussian Blur
grayed_blur = cv2.cvtColor(img_blur, cv2.COLOR_BGR2GRAY)
blurred = cv2.GaussianBlur(grayed_blur, (5, 5), 0)
cv2.imshow("Blurred", blurred)

#Sharpening
grayed_sharp = cv2.cvtColor(img_sharp, cv2.COLOR_BGR2GRAY)
sharpen_kernel = np.array([[0, -1, 0],
                           [-1, 5, -1],
                           [0, -1, 0]])
sharpened = cv2.filter2D(grayed_sharp, -1, sharpen_kernel)
cv2.imshow("Sharpened", sharpened)

#Edge Detection
grayed_edge = cv2.cvtColor(img_edge, cv2.COLOR_BGR2GRAY)
edges = cv2.Canny(grayed_edge, 100, 200)
cv2.imshow("Edges", edges)

#padding
grayed_pad = cv2.cvtColor(img_pad, cv2.COLOR_BGR2GRAY)
height, width = grayed_pad.shape
top = bottom = height // 2
left = right = width // 2
padded_img = cv2.copyMakeBorder(grayed_pad, top, bottom, left, right, cv2.BORDER_REFLECT)
cv2.imshow("Symmetrically Padded", padded_img)

#gaussian LPF
grayed_lpf = cv2.cvtColor(img_lpf, cv2.COLOR_BGR2GRAY)
blurred = cv2.GaussianBlur(grayed_lpf, (15, 15), 0)
cv2.imshow("Gaussian Low Pass", blurred)

#gaussian HPF
grayed_hpf = cv2.cvtColor(img_hpf, cv2.COLOR_BGR2GRAY)
blurred = cv2.GaussianBlur(grayed_hpf, (21, 21), 0)

"""here I used a clever thing to simulate the gaussian HPF
basically i subtracted the low frequencies so only high frequencies remain
thereby simulating a HPF closely """

highpass = cv2.subtract(grayed_hpf, blurred)
cv2.imshow("Gaussian High-Pass (Subtracted)", highpass)


#frequency domain filters
grayed_freq = cv2.cvtColor(img_freq, cv2.COLOR_BGR2GRAY)
rows, cols = grayed_freq.shape
crow, ccol = rows // 2 , cols // 2

# here i Compute DFT once
dft = cv2.dft(np.float32(grayed_freq), flags=cv2.DFT_COMPLEX_OUTPUT)
dft_shift = np.fft.fftshift(dft)

# here i Copy shifted DFT for LPF and HPF
dft_shift_lpf = dft_shift.copy()
dft_shift_hpf = dft_shift.copy()

# here i Create Circular Ideal Low Pass Filter Mask
cutoff = 50  # radius in pixels
mask_lpf = np.zeros((rows, cols, 2), np.uint8)
for u in range(rows):
    for v in range(cols):
        if (u - crow)**2 + (v - ccol)**2 <= cutoff**2:
            mask_lpf[u, v] = 1

# here i Apply the mask in frequency domain (LPF)
fshift_lpf = dft_shift_lpf * mask_lpf

# here i Inverse shift and inverse DFT (LPF)
f_ishift_lpf = np.fft.ifftshift(fshift_lpf)
img_back_lpf = cv2.idft(f_ishift_lpf)
img_back_lpf = cv2.magnitude(img_back_lpf[:, :, 0], img_back_lpf[:, :, 1])
img_back_lpf = cv2.normalize(img_back_lpf, None, 0, 255, cv2.NORM_MINMAX)
img_back_lpf = np.uint8(img_back_lpf)
cv2.imshow("Circular ILPF Result", img_back_lpf)

# Circular HPF
# here i Create a circular high-pass mask (0s inside, 1s outside)
mask_hpf = np.ones((rows, cols, 2), np.uint8)
for u in range(rows):
    for v in range(cols):
        if (u - crow)**2 + (v - ccol)**2 <= cutoff**2:
            mask_hpf[u, v] = 0  # block low frequencies

# here i Apply the mask in frequency domain (HPF)
fshift_hpf = dft_shift_hpf * mask_hpf

# here i Inverse shift and inverse DFT (HPF)
f_ishift_hpf = np.fft.ifftshift(fshift_hpf)
img_back_hpf = cv2.idft(f_ishift_hpf)
img_back_hpf = cv2.magnitude(img_back_hpf[:, :, 0], img_back_hpf[:, :, 1])
img_back_hpf = cv2.normalize(img_back_hpf, None, 0, 255, cv2.NORM_MINMAX)
img_back_hpf = np.uint8(img_back_hpf)
cv2.imshow("High-Pass Filtered", img_back_hpf)

cv2.waitKey(0)
cv2.destroyAllWindows()
