import cv2 as cv
import numpy as np
import os
import hand_tracking_module as htm

haar_cascade = cv.CascadeClassifier('haar_face.xml')

wcam, hcam = 640, 480
cap = cv.VideoCapture(0)
cap.set(3, wcam)
cap.set(4, hcam)
detector = htm.handDetector(detectionCon=0.75)
tipIds = [4, 8, 12, 16, 20]

while True:
    ret, frame = cap.read()
    if not ret:
        print("Failed to grab frame")
        break

    gray = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)
    faces_rect = haar_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=3)

    if len(faces_rect) > 0:
        print("face detected")
        detector.findHands(frame, draw=False)
        allHands = detector.findPosition(frame, draw=False)

        totalFingers = 0

        for lmList in allHands:
            if len(lmList) != 0:
                fingers = []

                if lmList[tipIds[0]][1] > lmList[tipIds[0] - 1][1]:
                    fingers.append(1)
                else:
                    fingers.append(0)

                # Other fingers
                for id in range(1, 5):
                    if lmList[tipIds[id]][2] < lmList[tipIds[id] - 2][2]:
                        fingers.append(1)
                    else:
                        fingers.append(0)

                totalFingers += fingers.count(1)

        cv.putText(frame, f'Fingers: {totalFingers}', (30, 100),
                   cv.FONT_HERSHEY_SIMPLEX, 2, (0, 255, 0), 5)
    else:
        print("no face")
        cv.putText(frame, f'Fingers:0', (30, 100),
                   cv.FONT_HERSHEY_SIMPLEX, 2, (0, 255, 0), 5)

    for (x, y, w, h) in faces_rect:
        cv.rectangle(frame, (x, y), (x + w, y + h), (255, 0, 0), 2)

    cv.imshow('Video Face + Finger Detection', frame)

    if cv.waitKey(20) & 0xFF == ord('q'):
        break

cap.release()
cv.destroyAllWindows()
